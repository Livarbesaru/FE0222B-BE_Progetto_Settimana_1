
public class Autofficina {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Macchina fiatPanda=new Macchina("Fiat Panda", 1200, "AA 123 BB", 12000, "giallo", 5);
		Macchina alfaGiulia=new Macchina("Alfa Giulia", 3200, "BB 246 CC", 36000, "rosso", 6);
		Macchina bmw318=new Macchina("Bmw 318", 1800, "CC 022 AA", 22000, "blu", 5);
		Macchina audiTT=new Macchina("Audi TT", 2200, "DD 111 BB", 28000, "grigia", 5);
		Macchina skodaFabia=new Macchina("Skoda Fabia", 1500, "HH 333 CC", 15000, "verde", 5);
		
		Macchina[] auto= {fiatPanda,alfaGiulia,bmw318,audiTT,skodaFabia};
		
		infoMacchinaPiuCostosa(auto);
		infoMacchina(auto,"cc 022 aa");
		infoMacchinaColore(auto,"giallo");
		fiatPanda.cambiaMarcia(2);
		fiatPanda.cambiaMarcia(3);
		fiatPanda.cambiaMarcia(3);
		fiatPanda.aumentaMarcia();
		fiatPanda.scalaMarcia();
		fiatPanda.accendiMotore();
		fiatPanda.spegniMotore();
		
	}
	
	static public void infoMacchinaPiuCostosa(Macchina[] autoArray){
		Macchina autoCostosa=autoArray[0];
		for(int i=0;i<autoArray.length;i++) {
			if(autoArray[i].getValore()>autoCostosa.getValore()) {
				autoCostosa=autoArray[i];
			}
		}
		if(autoCostosa!=null) {
			System.out.println("L'auto piu costosa e': "+autoCostosa.stampaInformazione());
		}
		else {
			System.out.println("non ci sono auto");
		}
	}
	
	static public void infoMacchina(Macchina[] autoArray,String targa){
		Macchina autoTarga=null;
		for(int i=0;i<autoArray.length;i++) {
			if((autoArray[i].getTarga().toUpperCase()).equals(targa.toUpperCase())) {
				autoTarga=autoArray[i];
				System.out.println("L'auto con targa '"+targa.toUpperCase()+ "' e': "+autoTarga.stampaInformazione());
			}
		}
		if(autoTarga==null) {
			System.out.println("L'auto con targa '"+targa.toUpperCase()+ " non esiste");
		}
	}
	
	static public void infoMacchinaColore(Macchina[] autoArray,String colore){
		Macchina autoColore=null;
		for(int i=0;i<autoArray.length;i++) {
			if((autoArray[i].getColore().toUpperCase()).equals(colore.toUpperCase())) {
				autoColore=autoArray[i];
				System.out.println("L'auto di colore "+colore.toUpperCase()+ " e': "+autoColore.stampaInformazione());
			}
		}
		if(autoColore==null) {
			System.out.println("L'auto con colore '"+colore.toUpperCase()+ " non esiste");
		}
	}

}
