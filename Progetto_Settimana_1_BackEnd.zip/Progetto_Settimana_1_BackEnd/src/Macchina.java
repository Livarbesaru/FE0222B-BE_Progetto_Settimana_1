
public class Macchina {
	private String nome;
	private int cilindrata;
	private String targa;
	private int prezzo;
	private String colore;
	private int numeroMarce;
	private boolean motoreAcceso;
	private int marcia;
	
	Macchina(String nome, int cilindrata,String targa,int prezzo,String colore,int numeroMarce){
		this.nome=nome;
		this.cilindrata=cilindrata;
		this.targa=targa;
		this.prezzo=prezzo;
		this.colore=colore;
		this.numeroMarce=numeroMarce;
		this.motoreAcceso=false;
		this.marcia=0;
	}
	
	public void accendiMotore() {
		if(this.motoreAcceso==false) {
			this.marcia=0;
			this.motoreAcceso=true;
			System.out.println(this.nome+": Il motore e' stato acceso e la marcia e' posizionata in folle(0)");
		}
		else {
			System.out.println(this.nome+": Il motore e' gia' acceso");
		}
	}
	
	public void spegniMotore() {
		if(this.motoreAcceso==true) {
			this.motoreAcceso=false;
			this.marcia=0;
			System.out.println(this.nome+": Il motore e' stato spento e la marcia e' posizionata in folle(0)");
		}
		else {
			System.out.println(this.nome+": Il motore e' gia' spento");
		}
	}
	
	public void cambiaMarcia(int marciaScelta) {
		if(marciaScelta==this.marcia) {
			System.out.println(this.nome+": La marcia scielta era gia' inserita");
		}
		else {
			if(marciaScelta >=0 && marciaScelta <= this.numeroMarce) {
				this.marcia=marciaScelta;
				System.out.println(this.nome+": La marcia scielta " +this.marcia+" e'stata inserita" );
			}
			else {
				System.out.println(this.nome+": Attenzione questa manovra non e' valida!");
			}
		}
	}
	
	public void scalaMarcia() {
		if(this.marcia>0 && this.marcia <= this.numeroMarce) {
			this.marcia--;
			System.out.println(this.nome+": Marcia cambiata, la marcia attuale e': "+ this.marcia);
		}
		else if(this.marcia==0) {
			System.out.println(this.nome+": Attenzione la marcia attuale e' folle(0), non esiste marcia inferiore");
		}
	}
	
	public void aumentaMarcia() {
		if(this.marcia>=0 && this.marcia < this.numeroMarce) {
			this.marcia++;
			System.out.println(this.nome+":Marcia cambiata, la marcia attuale e': "+ this.marcia);
		}
		else if(this.marcia==this.numeroMarce) {
			System.out.println(this.nome+": Attenzione la marcia attuale e' la massima: "+ this.marcia+", non esiste una marcia superiore");
		}
	}
	
	public String stampaInformazione() {
		String risposta="";
		risposta+=("\n" +"============Auto==========");
		risposta+=("\n" +" -Nome: " + this.nome);
		risposta+=("\n" +" -Cilindrata: " + this.cilindrata);
		risposta+=("\n" +" -Targa: " + this.getTarga());
		risposta+=("\n" +" -Prezzo: " + this.getValore());
		risposta+=("\n" +" -Colore: " + this.getColore());
		risposta+=("\n" +" -Marcie: " + this.numeroMarce);
		risposta+=("\n" +"===========================");
		return risposta;
	}

	public int getValore() {
		return this.prezzo;
	}

	public String getTarga() {
		return targa;
	}

	public String getColore() {
		return colore;
	}

}
